import { GoogleGenAI, Chat } from "@google/genai";
import { AnalysisResult } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to convert File to Base64
const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Data = reader.result as string;
      // Remove the data URL prefix (e.g., "data:application/pdf;base64,")
      const base64Content = base64Data.split(',')[1];
      resolve({
        inlineData: {
          data: base64Content,
          mimeType: file.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const analyzeResumeFit = async (
  resumeFile: File,
  jobUrl: string
): Promise<AnalysisResult> => {
  try {
    const resumePart = await fileToGenerativePart(resumeFile);

    // Use Gemini 2.5 Flash for speed and multimodal capabilities
    const model = 'gemini-2.5-flash';

    const prompt = `
      You are an expert Technical Recruiter and Hiring Manager.
      
      Task:
      1. Analyze the provided Resume (PDF).
      2. Find and analyze the Job Description located at this URL: "${jobUrl}".
         Use the Google Search tool to find the content of this URL or search for the job description if the direct URL is not accessible.
      
      Output Requirements:
      You MUST return a single valid JSON object. Do not return markdown code blocks. Do not include any explanatory text.
      The JSON object must strictly adhere to this structure:
      {
        "overallFitSummary": "A professional assessment of the candidate's fit for the role.",
        "candidateSkills": ["Skill 1", "Skill 2"],
        "requiredJobSkills": ["Skill A", "Skill B"],
        "gapAnalysis": ["Missing Skill X", "Missing Qualification Y"],
        "matchScore": 0 // Integer from 0 to 100 indicating the fit
      }
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          resumePart,
          { text: prompt }
        ]
      },
      config: {
        tools: [{ googleSearch: {} }], 
        // CRITICAL: responseMimeType is NOT supported when using tools.
        // We rely strictly on the prompt to enforce JSON structure.
      }
    });

    if (response.text) {
      let jsonString = response.text.trim();
      
      // Strip markdown code blocks if present (e.g. ```json ... ```)
      if (jsonString.startsWith('```')) {
        jsonString = jsonString.replace(/^```(?:json)?\n/, '').replace(/\n```$/, '');
      }
      
      // Clean up any potential leading/trailing non-JSON characters
      const startIndex = jsonString.indexOf('{');
      const endIndex = jsonString.lastIndexOf('}');
      
      if (startIndex !== -1 && endIndex !== -1) {
        jsonString = jsonString.substring(startIndex, endIndex + 1);
      }

      try {
        return JSON.parse(jsonString) as AnalysisResult;
      } catch (parseError) {
        console.error("Failed to parse JSON response:", jsonString);
        throw new Error("Failed to parse analysis results. The model did not return valid JSON.");
      }
    } else {
      throw new Error("No response text generated.");
    }

  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw error;
  }
};

// --- Chat Functionality ---

export const createChatSession = (result: AnalysisResult, jobUrl: string): Chat => {
  const systemInstruction = `
    You are a dedicated Career Coach and Resume Writer assisting a candidate.
    
    Context:
    - The candidate has applied for a job at: ${jobUrl}
    - Match Score: ${result.matchScore}/100.
    - Key Gaps: ${result.gapAnalysis.join(', ')}.
    
    Goal:
    - Strategize to improve their chances.
    - When asked to "Draft CV" or "Generate CV", generate a full ATS-COMPLIANT RESUME.
    
    ATS (Applicant Tracking System) CV Generation Rules:
    1. **Format**: Strict Markdown. Use standard headers.
    2. **Structure**:
       - # NAME & CONTACT (Do not use placeholders if not known, just use [Name])
       - ## PROFESSIONAL SUMMARY
       - ## SKILLS (Grouped logically)
       - ## EXPERIENCE (Reverse chronological, focus on achievements relevant to the job URL)
       - ## EDUCATION
       - ## PROJECTS (Optional)
    3. **Content**: 
       - Incorporate keywords from the job description naturally.
       - Use action verbs.
       - Avoid tables, columns, or complex graphics (ATS cannot read them).
       - Keep it clean, professional, and text-based.
    
    CRITICAL OUTPUT RULE:
    - If generating the CV, output ONLY the Markdown content starting with the Name header. 
    - Do not add conversational text like "Here is your CV" inside the CV generation turn.
    - If refining the CV based on feedback, RE-GENERATE the ENTIRE CV with the changes applied.
  `;

  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: systemInstruction,
    }
  });
};

export const sendChatMessage = async (chat: Chat, message: string): Promise<string> => {
  const response = await chat.sendMessage({ message });
  return response.text || "I'm sorry, I couldn't generate a response.";
};
