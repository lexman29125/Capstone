export interface AnalysisResult {
  overallFitSummary: string;
  candidateSkills: string[];
  requiredJobSkills: string[];
  gapAnalysis: string[];
  matchScore: number; // 0 to 100
}

export interface LogEntry {
  id: string;
  message: string;
  type: 'info' | 'success' | 'agent';
  timestamp: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export type ViewMode = 'analysis' | 'cv_preview';

export interface AppState {
  jobUrl: string;
  resumeFile: File | null;
  isLoading: boolean;
  logs: LogEntry[];
  result: AnalysisResult | null;
  error: string | null;
  chatMessages: ChatMessage[];
  viewMode: ViewMode;
  generatedCV: string | null;
}